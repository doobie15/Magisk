package com.topjohnwu.magisk.ui

import com.topjohnwu.magisk.ui.base.BaseViewModel

class MainViewModel : BaseViewModel()
