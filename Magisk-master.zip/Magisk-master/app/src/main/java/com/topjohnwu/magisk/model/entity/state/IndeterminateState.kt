package com.topjohnwu.magisk.model.entity.state

enum class IndeterminateState {
    CHECKED, INDETERMINATE, UNCHECKED
}
